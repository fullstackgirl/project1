# Column Drop Layout

### Color Codes To Be Used
* rgb(28, 69, 135) - dark blue
* rgb(60, 120,216) light blue
* rgb(201, 218, 248) slate blue


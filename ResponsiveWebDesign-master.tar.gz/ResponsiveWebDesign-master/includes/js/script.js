$(document).ready(function () {

    /*Change the font size as per Accessibility Guidelines*/

    var text_size_key_nm = "textSize";
    var originalFontSize = 10;
    var local_storage = window.localStorage;
    var mainTagOffsetTop = $('main').offset().top;
    var mainTagHeight = $('main').outerHeight();
    jQuery(".fontresr ul li a").removeClass("selected");
    if (local_storage.getItem(text_size_key_nm) == 12) {
        jQuery(".large").addClass("selected");
    } else if (local_storage.getItem(text_size_key_nm) == 8) {
        jQuery(".small").addClass("selected");
    } else {
        jQuery(".medium").addClass("selected");
    }
    if (local_storage.getItem(text_size_key_nm)) {
        var $getSize = local_storage.getItem(text_size_key_nm);
        $("html").css({
            fontSize: $getSize + ($getSize.indexOf("px") != -1 ? "" : "px")
        });
    } else {
        local_storage.setItem(text_size_key_nm, originalFontSize);
    }

    // Increase Font Size
    $(".small").click(function () {
        jQuery(".fontresr ul li a").removeClass("selected");
        $(this).addClass('selected');
        var currentFontSize = $('html').css('font-size');
        var currentFontSizeNum = parseFloat(currentFontSize, 10);
        var newFontSize = 8;
        $('html').css('font-size', newFontSize + 'px');
        local_storage.setItem(text_size_key_nm, newFontSize);
        return false;
    });
    // Decrease Font Size
    $(".medium").click(function () {
        jQuery(".fontresr ul li a").removeClass("selected");
        $(this).addClass('selected');
        var currentFontSize = $('html').css('font-size');
        var currentFontSizeNum = parseFloat(currentFontSize, 10);
        var newFontSize = 10;
        $('html').css('font-size', newFontSize + 'px');
        local_storage.setItem(text_size_key_nm, newFontSize);
        return false;
    });
    $(".large").click(function () {
        jQuery(".fontresr ul li a").removeClass("selected");
        $(this).addClass('selected');
        var currentFontSize = $('html').css('font-size');
        var currentFontSizeNum = parseFloat(currentFontSize, 10);
        var newFontSize = 12;
        $('html').css('font-size', newFontSize + 'px');
        local_storage.setItem(text_size_key_nm, newFontSize);

        return false;
    });

    $(".dropdown-menu li:last-child").focusout(function () {
        $(".dropdown-menu").parent().removeClass("open");
    });

    //fixed-header

    $(window).scroll(function () {
        var fxdNav = null;
        var _that = this;
        var topWindowPos = 0;
        var windowScrollTop = $(window).scrollTop();
        if ($(window).scrollTop() >= 138) {
            //fxdNav = $('.header').clone().addClass('fixed');
            //$('.fmc-navbar-collapse').addClass('fixed');
            if ($('.header.fixed').length > 0) {
                //do nothing
            } else {
                /*$('body').append(fxdNav);*/
                $('.header').addClass('fixed');
            }
        } else {
            $('.header').removeClass('fixed');
        }

        if ($("#step1").length > 0) {
            offLenth = $("#step1").offset().top - 50;

            if ($(window).scrollTop() > offLenth) {
                fxdPanel = $('.stick').clone().addClass('stick-on-desktop copied');
                if ($('.stick-on-desktop').length <= 0) {
                    $('body').append(fxdPanel);
                }
            } else {
                $('.stick.stick-on-desktop').remove();
            }
        }

        if ($('.stick-on-desktop').length > 0) {
            if (_that.oldScroll < _that.scrollY) {
                $('.stick-on-desktop').slideUp(300);
            } else {
                $('.stick-on-desktop').slideDown(300);
            }
            this.oldScroll = this.scrollY;
        }


        if ($('#potential-sticky-social-bar').length > 0) {
            var _articleStickyBar = $('#potential-sticky-social-bar');
            var offsetArtiSocialBar = _articleStickyBar.offset().top + _articleStickyBar.outerHeight() - 100;
            if ($(window).scrollTop() > offsetArtiSocialBar) {
                if ($('.made-sticky').length <= 0) {
                    var _cloneArticleStickyBar = $('#potential-sticky-social-bar').clone(true, true);
                    _cloneArticleStickyBar.addClass('made-sticky cont');
                    $('.progress', _cloneArticleStickyBar).removeClass('hidden');
                    $('.social-drop-bar', _cloneArticleStickyBar).hide();
                    $('body').append(_cloneArticleStickyBar);
                }
            } else {
                $('.made-sticky').remove();
            }
        }

        if ($('.made-sticky').length > 0) {
            var _percentProgress = (windowScrollTop / (mainTagOffsetTop + mainTagHeight - 300)) * 100;
            if (_percentProgress > 99 && _percentProgress <= 100) {
                _percentProgress = 100;
            }
            $('.made-sticky .progress-bar').css({
                width: _percentProgress + '%'
            }).attr('aria-valuenow', _percentProgress);
        }


    });

    $('.fmc-navbar-toggle').on('click', function () {
        if ($(this).hasClass('collapsed')) {
            $(this).addClass('active');
            $('<div class="nav-overlay"></div>').prependTo('body');
            $('body').addClass('nav-ov');
        } else {
            $('.nav-overlay').remove();
            $('body').removeClass('nav-ov');
            $(this).removeClass('active');
        }
    });

    $('.slidenav li').on('click', function () {
        var parentElm = $(this).closest('.carousel').attr('id');
        $('#' + parentElm).find('.slide').removeAttr('tabindex');
        $('#' + parentElm).find('.slide.current').attr('tabindex', -1).focus();
    });

    /* LedGen Form */

    $('.ref-toggle').on('click', function () {
        var data = $(this).data('id');
        if (data == 'ref-hide') {
            $('.ref-hide').addClass('hidden');
            $('.ref-show').removeClass('hidden');
        } else {
            $('.ref-show').addClass('hidden');
            $('.ref-hide').removeClass('hidden');
        }
    });

    $("#basicForm").validate({
        onfocusout: false
    });

    /* process module */
    $(document).on('click', '.stick ul li a', function (e) {
        // e.preventDefault();//commented to work linking from parent page
        var stickHt = null;
        if ($(this).parents('.stick').hasClass('stick-on-desktop')) {
            stickHt = ($(window).width() > 1200) ? $('.stick.stick-on-desktop').height() + 40 : $('.stick.stick-on-desktop').height() + 35;
        } else {
            stickHt = 123;
        }

        if ($(this).parents('.stick-steps').length > 0) {
            return;
        }

        var thisHref = $(this).attr("href");
        $('.stick ul li a').parent("li").removeClass("active")
        $(this).parent("li").addClass("active");
        $("html, body").animate({
            scrollTop: $(thisHref).offset().top - stickHt
        }, "slow");
        $(thisHref).focus();
        // return false;//commented to work linking from parent page
    });

    $(document).on("scroll", onScroll);

    function onScroll(event) {
        var scrollPos = $(document).scrollTop(),
            stickHt = ($(window).width() > 1200) ? $('.stick.stick-on-desktop').height() + 50 : $('.stick.stick-on-desktop').height() + 35;
        if ($(".stick-on-desktop").length > 0) {
            $('.stick-on-desktop li a').each(function () {
                var currLink = $(this);
                var refElement = $(currLink.attr("href"));
                if (refElement.position().top - stickHt <= scrollPos && (refElement.position().top - stickHt) + refElement.outerHeight() > scrollPos) {
                    $('.stick li a').parent("li").removeClass("active");
                    currLink.parent("li").addClass("active");
                    $('.stick-on-desktop').scrollLeft(currLink.parent("li").offset().left - currLink.parent("li").parent().offset().left);
                } else {
                    currLink.parent("li").removeClass("active");
                }
            });
        }
    }

    //back-to-top
    if ($('.back-to-top').length) {
        var scrollTrigger = 200, // px
            backToTop = function () {
                var scrollTop = $(window).scrollTop(),
                    htblock = $('.footer').offset().top - $(window).height();
                if (scrollTop > scrollTrigger) {
                    $('.back-to-top').addClass('show');
                } else {
                    $('.back-to-top').removeClass('show');
                }
                if (scrollTop >= htblock) {
                    $('.back-to-top,.fc-link-float').addClass('foot-in');
                } else {
                    $('.back-to-top,.fc-link-float').removeClass('foot-in');
                }
            };
        backToTop();
        $(window).on('scroll', function () {
            backToTop();
        });
        $('.back-to-top,.gl-top').on('click', function (e) {
            e.preventDefault();
            $('html,body').animate({
                scrollTop: 0
            }, 700);
            $('h1').attr('tabindex', -1).focus();
        });
    }

    //mailto
    if ($('.svglinks .mail').length > 0) {
        $('.svglinks .mail').on("click", function (e) {

            e.preventDefault();
            var email = $(this).data('mid'),
                subject = $(this).data('msub'),
                body_message = document.title + '%20' + location.href;

            var mailto_link = 'mailto:' + email + '?subject=' + subject + '&body=' + body_message;

            win = window.open(mailto_link, 'emailWindow');
        });
    }

    $('.popular-questions a').on('click', function (e) {
        e.preventDefault();
        var stickHt = null;
        if ($(window).width() > 1200) {
            stickHt = 50;
        } else {
            stickHt = 0;
        }

        var thisHref = $(this).attr("href");
        if ($(thisHref).length <= 0) {
            return false;
        }
        //$('.stick ul li a').parent("li").removeClass("active");
        //$(this).parent("li").addClass("active");
        $("html, body").animate({
            scrollTop: $(thisHref).offset().top - stickHt
        }, "slow");
        /* $(thisHref).find('.panel-title a').trigger('click').attr('tabindex', -1).focus(); */
        $(thisHref).find('.panel-title a').attr('tabindex', -1).focus();
        $(thisHref).find('.panel-collapse').collapse('show');
    });



    //Glossary links
    if ($('.glossary-letters-container').length > 0) {
        $('.glossary-letters-container a').on('click', function (e) {

            e.preventDefault();
            var stickHt = null,
                thisHref = $(this).attr("href");
            if ($(window).width() > 1200) {
                stickHt = 50;
            } else {
                stickHt = 0;
            }

            if ($($(this).attr("href")).length <= 0) {
                return;
            }

            $("html, body").animate({
                scrollTop: $(thisHref).offset().top - stickHt
            }, "slow");
            $(thisHref).attr('tabindex', -1).focus();
        });

    }

    var frm = $(".campaign-form");
    var Privileges = $('.campaign-form #LoanType');
    Privileges.change(function () {
        if ($(this).val() === 'Purchase') {
            $('.hide-purchase').hide();
        } else {
            $('.hide-purchase').show();
        }
    });

    //  dropdown functionality
    $('.dropdown .dropdown-menu li a').on('click', function (e) {
        e.preventDefault();
        var _parent = $(this).closest('.dropdown');
        $('.dropdown-toggle', _parent).html('' + $(this).text() + '<span class="caret"></span>');
    });

    $('.tips-insights-wrapper .dropdown .dropdown-menu li a').on('click', function (e) {
        e.preventDefault();
        var _val = $(this).attr('data-val');
        $('.va-tips-insights-cat').hide().removeAttr('tabindex');
        if (_val != 0) {
            $('.' + _val).show().attr('tabindex', -1).focus();
        } else {
            $('.va-tips-insights-cat').show();
        }
    });

    $('#faq-dropdown .dropdown-menu li a').on('click', function (e) {
        e.preventDefault();
        var _val = $(this).attr('data-val');
        $('.faqs-sect').hide().removeAttr('tabindex');
        if (_val != 0) {
            $('.' + _val).show().attr('tabindex', -1).focus();
        } else {
            $('.faqs-sect').show();
        }
    });

    $('.social-share-ico').off('click').on('click', function (e) {
        $(this).parent('li').find('.social-drop-bar').slideToggle();
    });

});

$(window).on('load', function () {
    //to leadgen form -- down arrow
    if ($('.to-form').length > 0) {
        var varHt = $('#loanType').offset().top - $(window).height() + 70;
        $('.to-form .down-arrow').on('click', function (e) {

            e.preventDefault();
            var stickHt = null,
                thisHref = $(this).attr("href");

            if ($(window).width() > 1200) {
                stickHt = 50;
            } else {
                stickHt = 0;
            }

            $("html, body").animate({
                scrollTop: $(thisHref).offset().top - stickHt
            }, "slow");
            $(thisHref).attr('tabindex', -1).focus();
        });

        //add - remove class hidden
        if ($(window).scrollTop() <= varHt) {
            $('.to-form').removeClass('hidden');
        } else {
            $('.to-form').addClass('hidden');
        }
        $(window).scroll(function () {
            if ($(window).scrollTop() <= varHt) {
                $('.to-form').removeClass('hidden');
            } else {
                $('.to-form').addClass('hidden');
            }
        });
    }
});

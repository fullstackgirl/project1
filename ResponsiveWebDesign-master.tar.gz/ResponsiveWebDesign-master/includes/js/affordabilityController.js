// 7/7/2016 - affordabilityController.js
// 2/1/2017 - api call updated and default rates values

$(document).bind('mobileinit', function() {
    $.mobile.pushStateEnabled = false;
});

var calculator = calculator || {};

/*
var rate15Today, rate30Today, ratesCallback = function(xhr) {
    if(xhr && xhr.response && xhr.response.today) {
        rate15Today = parseFloat(xhr.response.today.fifteenYearFixed);
        rate30Today = parseFloat(xhr.response.today.thirtyYearFixed);
    }
    calculator.affordability.init();
};
*/

// default rates if api does not work
var rate15Today = 3.0, rate30Today = 4.0;


$(function() {
    $(function() {
        $('[data-toggle="tooltip"]').tooltip()
    });

    $(document).on("ready", function() {

    /*    $.ajax({
            url: 'https://www.zillow.com/webservice/GetRateSummary.htm?zws-id=X1-ZWz1f5i5cb28zv_4u6i7&output=json&state=IA&callback=ratesCallback',
            dataType: 'jsonp'
        });  */


        $.ajax({
            url: 'https://mortgageapi.zillow.com/getRates?partnerId=RD-PFGCMXZ&includeCurrentRate=true&queries.FIXED30.program=Fixed30Year&queries.FIXED20.program=Fixed20Year&queries.FIXED15.program=Fixed15Year&queries.FIXED10.program=Fixed10Year&queries.ARM3.program=ARM3&queries.ARM5.program=ARM5&queries.ARM7.program=ARM7&queries.US.propertyBucket.propertyValue=300000&queries.US.propertyBucket.loanAmount=240000&queries.US.propertyBucket.location.stateAbbreviation=US&durationDays=365&aggregation=Monthly',
            jsonp: false,
            cache: true,
            complete: function(res) {
                if(res && res.responseJSON && res.responseJSON.rates) {
                    var rates = res.responseJSON.rates;

                    if(rates.FIXED15 && rates.FIXED15.currentRate && rates.FIXED15.currentRate.rate) {
                        rate15Today = parseFloat( (rates.FIXED15.currentRate.rate).toFixed(2) );
                    }

                    if(rates.FIXED30 && rates.FIXED30.currentRate && rates.FIXED30.currentRate.rate) {
                        rate30Today = parseFloat( (rates.FIXED30.currentRate.rate).toFixed(2) );
                    }
                }
                calculator.affordability.init();
            }
        });


        $('.year-income').on('change', function() {
            var value = $(this).val().replace(/[,$]/g,"");

            $(this).val(calculator.affordability.toCurrencyString(value));
        });

        $('.monthly-expenses').on('change', function() {
            var value = $(this).val().replace(/[,$]/g,"");

            $(this).val(calculator.affordability.toCurrencyString(value));
        });

        $('.down-payment-rate').on('blur', function() {
            var value = $(this).val();

            if(value.indexOf('%') === -1) {
                $(this).val(calculator.affordability.fixFloatValue(value) + '%');
            }
        });

        $('.perc-rate').on('blur', function() {
            var value = $(this).val();

            if(value.indexOf('%') === -1) {
                $(this).val(calculator.affordability.fixFloatValue(value) + '%');
            }
        });

        $('.down-payment-rate').on('keypress', function(e) {
            if(e.keyCode === 13) {
                var value = $(this).val();

                if(value.indexOf('%') === -1) {
                    $(this).val(calculator.affordability.fixFloatValue(value) + '%');
                }
            }
        });

        $('.perc-rate').on('keypress', function(e) {
            if(e.keyCode === 13) {
                var value = $(this).val();

                if(value.indexOf('%') === -1) {
                    $(this).val(calculator.affordability.fixFloatValue(value) + '%');
                }
            }
        });

        $('.year-income').on('keyup', function() {
            var stringValue = $(this).val().replace(/[,]/g, ''),
                dollarValue = stringValue.indexOf('$') === -1 ? parseInt(stringValue) : parseInt(stringValue.substring(1)),
                minValue = parseInt(calculator.affordability.$yearIncome.attr('data-slider-min')),
                maxValue = parseInt(calculator.affordability.$yearIncome.attr('data-slider-max'));

            if(dollarValue < minValue) {
                dollarValue = minValue;
                $(this).val(calculator.affordability.toCurrencyString(dollarValue));
            }
            if(dollarValue > maxValue) {
                dollarValue = maxValue;
                $(this).val(calculator.affordability.toCurrencyString(dollarValue));
            }

            if(stringValue.indexOf('$') === -1) {
                $(this).val(calculator.affordability.toCurrencyString(dollarValue));
            }

            calculator.affordability.yearIncomeSlider.bootstrapSlider('setValue',dollarValue, false, true);
        });

        $('.monthly-expenses').on('keyup', function() {
            var stringValue = $(this).val().replace(/[,]/g, ''),
                dollarValue = stringValue.indexOf('$') === -1 ? parseInt(stringValue) : parseInt(stringValue.substring(1)),
                minValue = parseInt(calculator.affordability.$monthlyExpenses.attr('data-slider-min')),
                maxValue = parseInt(calculator.affordability.$monthlyExpenses.attr('data-slider-max'));

            if(dollarValue < minValue) {
                dollarValue = minValue;
                $(this).val(calculator.affordability.toCurrencyString(dollarValue));
            }
            if(dollarValue > maxValue) {
                dollarValue = maxValue;
                $(this).val(calculator.affordability.toCurrencyString(dollarValue));
            }

            if(stringValue.indexOf('$') === -1) {
                $(this).val(calculator.affordability.toCurrencyString(dollarValue));
            }

            calculator.affordability.monthlyExpensesSlider.bootstrapSlider('setValue',dollarValue, false, true);
        });

        $('.down-payment-rate').on('keyup', function() {
            var stringValue = $(this).val(),
                percentValue = stringValue.indexOf('%') === -1 ? parseFloat(stringValue) : parseFloat(stringValue.substring(0, stringValue.length - 1)),
                minValue = parseFloat(calculator.affordability.$downPayment.attr('data-slider-min')),
                maxValue = parseFloat(calculator.affordability.$downPayment.attr('data-slider-max'));

            if(percentValue < minValue) {
                percentValue = minValue;
                $(this).val(percentValue + '%');
            }
            if(percentValue > maxValue) {
                percentValue = maxValue;
                $(this).val(percentValue + '%');
            }

            calculator.affordability.downPaymentSlider.bootstrapSlider('setValue',percentValue, false, true);
        });

        var _this;

        calculator.affordability = {
            init: function() {
                _this = this;

                _this.$loanRate = $('.perc-rate');

                _this.initSlider();

                _this.$yearIncome = $('#year-income')
                _this.$monthlyExpenses = $('#monthly-expenses');
                _this.$downPayment = $('#down-payment-rate');
                _this.$newLoanTerm = $('#new-loan-term');

                _this.bindActions();
            },
            bindActions: function() {
                $('#year-income, #monthly-expenses, #down-payment-rate, #new-loan-term, #perc-rate').on('change', function() {
                    var id = $(this).attr('id'),
                        $input = $('input[data-value="' + id + '"]'),
                        value = $(this).val();

                    if($input.length > 0) {
                        if($input.val().indexOf('$') !== -1) {
                            $input.val(_this.toCurrencyString(value));
                        }
                        else if($input.val().indexOf('%') !== -1) {
                            $input.val(value + '%');
                        }
                    }

                    _this.calculateMortgage();
                });

                $('#new-loan-term').on('change', function() {
                    var yearValue = $(this).val();

                    if(yearValue === "15") {
                        _this.$loanRate.val(rate15Today + '%');
                    } else if(yearValue === "30") {
                        _this.$loanRate.val(rate30Today + '%');
                    }
                });

                $('.perc-rate').on('keyup', function() {
                    _this.calculateMortgage();
                });

                $('#year-income').trigger('change');
            },
            fixFloatValue: function(stringValue) {

                stringValue = stringValue.replace(/[,!@#$^&*()-+'"№:;=_]/g, '');

                var firstDotIndex = stringValue.indexOf('.'),
                    lastDotIndex = stringValue.lastIndexOf('.');

                if(firstDotIndex !== lastDotIndex) {
                    return _this.fixFloatValue(stringValue.substring(0, firstDotIndex) + stringValue.substring(firstDotIndex + 1));
                }
                else {
                    if(firstDotIndex === -1) {
                        return stringValue;
                    } else {
                        return parseFloat(stringValue);
                    }
                }
            },
            calculateMortgage: function() {
                var yearincome = parseInt(_this.$yearIncome.val(), 10),
                    downPaymentRate = parseInt(_this.$downPayment.val(), 10) / 100.0,
                    monthlyExpenses = parseInt(_this.$monthlyExpenses.val(), 10),
                    years = parseInt(_this.$newLoanTerm.val(), 10),
                    loanRate = _this.$loanRate.val().indexOf('%') === - 1 ? parseFloat(_this.$loanRate.val()) : parseFloat(_this.$loanRate.val().substring(0, _this.$loanRate.val().length - 1)),
                    estimate = 0.36;

                var monthlyMortgage = Math.round((yearincome / 12.0) * estimate - monthlyExpenses);

                if(monthlyMortgage <= 0) {
                    $('.alert-danger').show();
                    return false;
                } else {
                    $('.alert-danger').hide();
                }

                $('.mmortage .value').html(_this.toCurrencyString(monthlyMortgage));

                var r = loanRate/1200,
                    n = years * 12,
                    x = Math.pow(1 + r, n);

                var estimatedIncome = x * r === 0 ? 0 : Math.round(monthlyMortgage * ( (x - 1) / (x * r) ));

                $('.estimate .value').html(_this.toCurrencyString(estimatedIncome));

                var downPayment = Math.round(estimatedIncome * downPaymentRate);

                $('.down-payment .value').html(_this.toCurrencyString(downPayment));

                var totalBorrowed = estimatedIncome - downPayment;

                $('.total-borrowed .value').html(_this.toCurrencyString(totalBorrowed));

                if(_this.$chart) {
                    _this.updateChart(totalBorrowed, downPayment);
                }
                else {
                    _this.initChart(totalBorrowed, downPayment);
                }
            },
            initChart: function(totalBorrowed, downPayment) {
                var settings = {
                    type: 'doughnut',
                    data: {
                        labels: ['Total Borrowed', 'Down Payment'],
                        datasets: [
                            {
                                data: [totalBorrowed, downPayment],
                                backgroundColor: ["#ffffff", "#36ae29"],
                                hoverBackgroundColor: ["#ffffff", "#36ae29"],
                                borderWidth: 2,
                                hoverBorderColor: ["#ffffff", "#36ae29"]
                            }]
                    },
                    options: {
                        title: {
                            display: false
                        },
                        legend: {
                            display: false
                        },
                        tooltips: {
                            enabled: false
                        },
                        segmentShowStroke: false,
                        cutoutPercentage: 80,
                        responsive: false
                    }
                };

                _this.$chart = new Chart($('#myChart'), settings);
            },
            updateChart: function(totalBorrowed, downPayment) {
                _this.$chart.data.datasets[0].data[0] = totalBorrowed;
                _this.$chart.data.datasets[0].data[1] = downPayment;

                setTimeout(_this.$chart.update(), 2000);
            },
            initSlider: function() {

                _this.yearIncomeSlider = $("#year-income").bootstrapSlider({
                    ticks: [0, 130000, 260000, 400000],
                    ticks_positions: [0, 33, 67, 100],
                    step: 5000,
                    ticks_labels: ['$0', '$130k', '$260k', '$400k']
                });
                _this.monthlyExpensesSlider = $("#monthly-expenses").bootstrapSlider({
                    ticks: [0, 1600, 3200, 5000],
                    ticks_positions: [0, 33, 67, 100],
                    step: 100,
                    ticks_labels: ['$0', '$1600', '$3200', '$5000']
                });

            /*  _this.downPaymentSlider = $("#down-payment-rate").bootstrapSlider({
                    ticks: [0, 10, 20, 30, 40, 50],
                    step: 10,
                    ticks_labels: ['', '10%', '20%', '30%', '40%', '']
                });
            */

                _this.downPaymentSlider = $("#down-payment-rate").bootstrapSlider({
                    ticks: [0, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50],
					ticks_positions: [0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100],
                    step: 5,
                    ticks_labels: ['0%','', '10%', '', '20%', '', '30%', '', '40%', '', '50%']					
                });

                _this.$loanRate.val(rate30Today + '%');

                $("#year-income").on("slide", function(slideEvt) {
                    $(".year-income").val(_this.toCurrencyString(slideEvt.value));
                });

                $("#monthly-expenses").on("slide", function(slideEvt) {
                    $(".monthly-expenses").val(_this.toCurrencyString(slideEvt.value));
                });

                $("#down-payment-rate").on("slide", function(slideEvt) {
                    $(".down-payment-rate").val(slideEvt.value + '%');
                });
            },
            toCurrencyString: function(number) {
                var prefix = number < 0 ? "-" : "";
                number = Math.abs(number) + '';
                if(number.length > 3 && number.length < 7) {
                    return prefix + '$' + number.substring(0, number.length - 3) + ',' + number.substring(number.length -3);
                }
                else if (number.length >= 7) {
                    return prefix + '$' + number.substring(0, number.length - 6) + ',' + number.substring(number.length - 6, number.length - 3) + ',' + number.substring(number.length - 3);
                } else return prefix + '$' + number;
            }
        };
    });
});
$(document).ready(function() {
    $(".errorMsg").hide();
    var container = $('div.errorMsg');

    jQuery.validator.addMethod("alphabetsOnly", function(value, element) {
        return this.optional(element) || /^[A-Za-z]{3,}$/.test(value);
    });

    $("#loanType").validate({
        focusInvalid: false,
        onfocusout: false,
        errorClass: "error",
        errorElement: 'span',
        errorContainer: container,
        errorLabelContainer: $("ol", container),
        wrapper: 'li',
        rules: {
            email: {
                required: true,
                email: true
            },
            firstName: {
                required: true,
                alphabetsOnly: true
            },
            lastName: {
                required: true,
                alphabetsOnly: true
            },
            phoneNum: "required",
            PropertyState: "required",
            PurchasePrice: "required",
            DownPayment: "required",
            LoanAmount: "required",
            PropertyValue: "required",
            loanType: "required",
            SelLoan: "required",
            City: "required",
            ZipCode: "required",
            collegeName: "required",
            Graduation: "required",
            Major: "required",
            Location: "required",
            about: "required"
        },
        messages: {
            loanType: "Loan Type - Select at least one loan type.",
            SelLoan: "Loan Type - Select at least one loan type.",
            email: {
                required: "We need your email address to contact you.",
                email: "Your email address must be in the format of name@domain.com."
            },
            firstName: {
                required: "First Name - This information is required.",
                alphabetsOnly: "Your First Name must be in letters with minimum 3 characters."
            },
            lastName: {
                required: "Last Name - This information is required.",
                alphabetsOnly: "Your Last Name must be in letters with minimum 3 characters."
            },
            phoneNum: "Phone Number - This information is required.",
            PropertyState: "Property State - This information is required.",
            PurchasePrice: "Purchase Price - This information is required.",
            DownPayment: "Down Payment - This information is required.",
            LoanAmount: "Loan Amount - This information is required.",
            PropertyValue: "Property Value - This information is required.",
            City: "City - This information is required.",
            PropertyAddress: "Property Address - This information is required.",
            ZipCode: "ZipCode - This information is required.",
            collegeName: "College Name - This information is required.",
            Graduation: "Graduation - This information is required.",
            Major: "Major - This information is required.",
            Location: "Location - This information is required.",
            about: "How did you hear about us ? - This information is required."
        },
        invalidHandler: function(event, validator) {
            var errors = validator.numberOfInvalids();
            if (errors) {
                $("div.errorMsg").show().focus();
                //message = errors == 1 ? 'You missed 1 field in your form submission, please see below for details.' : 'There are ' + errors + ' errors in your form submission, please see below for details.';
                $("div.errorMsg h3").remove();
                $("div.errorMsg").prepend("<h3>The following error(s) found in your form submission, please see below for details.</h3>");
            } else {
                ("div.errorMsg").hide();
            }
        },
        highlight: function(element, errorClass) {
            setTimeout(function() {
                $(element).addClass('error');
                var span = $("span[for=" + element.id + "]");
                console.log(element.id);
                if (span && span.length > 0) {
                    span.attr('id', 'err_' + element.id);
                }
            }, 10);
        },
        submitHandler: function(form) {
            form.submit();
        }
    });

    /*$('.frmField').on('change', function() {
        $("#loanType").valid();
    });*/
});